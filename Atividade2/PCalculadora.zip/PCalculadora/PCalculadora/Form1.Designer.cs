﻿namespace PCalculadora
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.lbl1 = new System.Windows.Forms.Label();
            this.lblresul = new System.Windows.Forms.Label();
            this.lbl2 = new System.Windows.Forms.Label();
            this.btnlimpar = new System.Windows.Forms.Button();
            this.txt1 = new System.Windows.Forms.TextBox();
            this.txtresultado = new System.Windows.Forms.TextBox();
            this.txt2 = new System.Windows.Forms.TextBox();
            this.btnmais = new System.Windows.Forms.Button();
            this.btndiv = new System.Windows.Forms.Button();
            this.btnmultip = new System.Windows.Forms.Button();
            this.btnmenos = new System.Windows.Forms.Button();
            this.btnsair = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // lbl1
            // 
            this.lbl1.AutoSize = true;
            this.lbl1.Location = new System.Drawing.Point(87, 63);
            this.lbl1.Name = "lbl1";
            this.lbl1.Size = new System.Drawing.Size(53, 13);
            this.lbl1.TabIndex = 0;
            this.lbl1.Text = "Numero 1";
            // 
            // lblresul
            // 
            this.lblresul.AutoSize = true;
            this.lblresul.Location = new System.Drawing.Point(87, 216);
            this.lblresul.Name = "lblresul";
            this.lblresul.Size = new System.Drawing.Size(55, 13);
            this.lblresul.TabIndex = 1;
            this.lblresul.Text = "Resultado";
            // 
            // lbl2
            // 
            this.lbl2.AutoSize = true;
            this.lbl2.Location = new System.Drawing.Point(87, 133);
            this.lbl2.Name = "lbl2";
            this.lbl2.Size = new System.Drawing.Size(53, 13);
            this.lbl2.TabIndex = 2;
            this.lbl2.Text = "Numero 2";
            // 
            // btnlimpar
            // 
            this.btnlimpar.Location = new System.Drawing.Point(562, 53);
            this.btnlimpar.Name = "btnlimpar";
            this.btnlimpar.Size = new System.Drawing.Size(134, 52);
            this.btnlimpar.TabIndex = 3;
            this.btnlimpar.Text = "Limpar";
            this.btnlimpar.UseVisualStyleBackColor = true;
            this.btnlimpar.Click += new System.EventHandler(this.Btnlimpar_Click);
            // 
            // txt1
            // 
            this.txt1.Location = new System.Drawing.Point(302, 63);
            this.txt1.Name = "txt1";
            this.txt1.Size = new System.Drawing.Size(135, 20);
            this.txt1.TabIndex = 6;
            this.txt1.Validated += new System.EventHandler(this.Txt1_Validated);
            // 
            // txtresultado
            // 
            this.txtresultado.Enabled = false;
            this.txtresultado.Location = new System.Drawing.Point(302, 213);
            this.txtresultado.Name = "txtresultado";
            this.txtresultado.Size = new System.Drawing.Size(135, 20);
            this.txtresultado.TabIndex = 7;
            // 
            // txt2
            // 
            this.txt2.Location = new System.Drawing.Point(302, 133);
            this.txt2.Name = "txt2";
            this.txt2.Size = new System.Drawing.Size(135, 20);
            this.txt2.TabIndex = 8;
            this.txt2.Validated += new System.EventHandler(this.Txt2_Validated);
            // 
            // btnmais
            // 
            this.btnmais.Location = new System.Drawing.Point(90, 324);
            this.btnmais.Name = "btnmais";
            this.btnmais.Size = new System.Drawing.Size(100, 66);
            this.btnmais.TabIndex = 9;
            this.btnmais.Text = "+";
            this.btnmais.UseVisualStyleBackColor = true;
            this.btnmais.Click += new System.EventHandler(this.Btnmais_Click);
            // 
            // btndiv
            // 
            this.btndiv.Location = new System.Drawing.Point(562, 324);
            this.btndiv.Name = "btndiv";
            this.btndiv.Size = new System.Drawing.Size(100, 66);
            this.btndiv.TabIndex = 10;
            this.btndiv.Text = "/";
            this.btndiv.UseVisualStyleBackColor = true;
            this.btndiv.Click += new System.EventHandler(this.Btndiv_Click);
            // 
            // btnmultip
            // 
            this.btnmultip.Location = new System.Drawing.Point(412, 324);
            this.btnmultip.Name = "btnmultip";
            this.btnmultip.Size = new System.Drawing.Size(100, 66);
            this.btnmultip.TabIndex = 11;
            this.btnmultip.Text = "*";
            this.btnmultip.UseVisualStyleBackColor = true;
            this.btnmultip.Click += new System.EventHandler(this.Btnmultip_Click);
            // 
            // btnmenos
            // 
            this.btnmenos.Location = new System.Drawing.Point(253, 324);
            this.btnmenos.Name = "btnmenos";
            this.btnmenos.Size = new System.Drawing.Size(100, 66);
            this.btnmenos.TabIndex = 12;
            this.btnmenos.Text = "-";
            this.btnmenos.UseVisualStyleBackColor = true;
            this.btnmenos.Click += new System.EventHandler(this.Btnmenos_Click);
            // 
            // btnsair
            // 
            this.btnsair.Location = new System.Drawing.Point(562, 133);
            this.btnsair.Name = "btnsair";
            this.btnsair.Size = new System.Drawing.Size(134, 52);
            this.btnsair.TabIndex = 13;
            this.btnsair.Text = "Sair";
            this.btnsair.UseVisualStyleBackColor = true;
            this.btnsair.Click += new System.EventHandler(this.Btnsair_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.btnsair);
            this.Controls.Add(this.btnmenos);
            this.Controls.Add(this.btnmultip);
            this.Controls.Add(this.btndiv);
            this.Controls.Add(this.btnmais);
            this.Controls.Add(this.txt2);
            this.Controls.Add(this.txtresultado);
            this.Controls.Add(this.txt1);
            this.Controls.Add(this.btnlimpar);
            this.Controls.Add(this.lbl2);
            this.Controls.Add(this.lblresul);
            this.Controls.Add(this.lbl1);
            this.Name = "Form1";
            this.Text = "Form1";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lbl1;
        private System.Windows.Forms.Label lblresul;
        private System.Windows.Forms.Label lbl2;
        private System.Windows.Forms.Button btnlimpar;
        private System.Windows.Forms.TextBox txt1;
        private System.Windows.Forms.TextBox txtresultado;
        private System.Windows.Forms.TextBox txt2;
        private System.Windows.Forms.Button btnmais;
        private System.Windows.Forms.Button btndiv;
        private System.Windows.Forms.Button btnmultip;
        private System.Windows.Forms.Button btnmenos;
        private System.Windows.Forms.Button btnsair;
    }
}

