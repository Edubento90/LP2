﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PCalculadora
{
    public partial class Form1 : Form
    {
        double numero1, numero2, resultado;

        public Form1()
        {

            InitializeComponent();
        }

        private void Btnmais_Click(object sender, EventArgs e)
        {
            if (Double.TryParse(txt1.Text, out numero1)&&
                Double.TryParse(txt2.Text, out numero2))
            {
                resultado = numero1 + numero2;

                txtresultado.Text = resultado.ToString();
            }

            else
                MessageBox.Show("número inválido");

        }

        private void Btnmenos_Click(object sender, EventArgs e)
        {
            if (Double.TryParse(txt1.Text, out numero1) &&
               Double.TryParse(txt2.Text, out numero2))
            {
                resultado = numero1 - numero2;

                txtresultado.Text = resultado.ToString();
            }

            else
                MessageBox.Show("número inválido");
        }

        private void Btnmultip_Click(object sender, EventArgs e)
        {
            if (Double.TryParse(txt1.Text, out numero1) &&
               Double.TryParse(txt2.Text, out numero2))
            {
                resultado = numero1 * numero2;

                txtresultado.Text = resultado.ToString();
            }

            else
                MessageBox.Show("número inválido");
        }

        private void Btndiv_Click(object sender, EventArgs e)
        {
            if (Double.TryParse(txt1.Text, out numero1) &&
               Double.TryParse(txt2.Text, out numero2))
            {
                resultado = numero1 / numero2;

                txtresultado.Text = resultado.ToString();
            }

            else
                MessageBox.Show("número inválido");
        }

        private void Btnsair_Click(object sender, EventArgs e)
        {
            
            Close();

        }

        private void Btnlimpar_Click(object sender, EventArgs e)
        {
            txt1.Clear();
            txt2.Clear();
            txtresultado.Clear();
        }

        private void Txt2_Validated(object sender, EventArgs e)
        {
            if (!Double.TryParse(txt2.Text, out numero2))
            {
            MessageBox.Show("Número 2 inválido!");
            }

        }

    private void Txt1_Validated(object sender, EventArgs e)
    {


        if (!Double.TryParse(txt1.Text, out numero1))
        {
            MessageBox.Show("Número 1 inválido!");
        }
    }
}
}
